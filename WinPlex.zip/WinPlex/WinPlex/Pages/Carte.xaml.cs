﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Controls.Maps;
using Windows.Devices.Geolocation;
using Windows.UI.Xaml.Shapes;
using Windows.UI;

// Pour plus d'informations sur le modèle d'élément Page vierge, consultez la page https://go.microsoft.com/fwlink/?LinkId=234238

namespace WinPlex
{
    /// <summary>
    /// Une page vide peut être utilisée seule ou constituer une page de destination au sein d'un frame.
    /// </summary>
    public sealed partial class Carte : Page
    {
        public Carte()
        {
            this.InitializeComponent();
        }


        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                var positionCarte = await LocationManager.GetPosition();
                MapControl MapControl = new MapControl();

                Geolocator geolocator = new Geolocator();
                Geopoint maPosition = positionCarte.Coordinate.Point;

                MapControl.Center = maPosition;
                MapControl.ZoomLevel = 17;
                MapControl.LandmarksVisible = true;

                MapControl.ZoomInteractionMode = MapInteractionMode.GestureAndControl;
                MapControl.TiltInteractionMode = MapInteractionMode.GestureAndControl;
                MapControl.MapServiceToken = "0aqqHOdrr4Bx0KpryC9H~tRWMQxu53JxjobxIcwp2SA~Av5NC5LorOqRxASC5dOc_24qCC2phzRx50E3IGaltOI9IUZmbn207R1crJ-wdU4Z";

                var pointInteret = new List<MapElement>();

                var position = new MapIcon
                {
                    Location = maPosition,
                    NormalizedAnchorPoint = new Point(0.5, 1.0),
                    ZIndex = 5,
                    Title = "Votre Position"
                };

                pointInteret.Add(position);

                var pointInteretStyle = new MapElementsLayer
                {
                    ZIndex = 1,
                    MapElements = pointInteret
                };

                MapControl.Layers.Add(pointInteretStyle);

                pageGrid.Children.Add(MapControl);

            }
            catch
            {
                TextBlock noInternet = new TextBlock();
                noInternet.Text = "Impossible d'afficher la carte veuillez activer la géolocalisation ou réaissez ultérieurement.";
                noInternet.HorizontalTextAlignment = TextAlignment.Center;
                noInternet.VerticalAlignment = VerticalAlignment.Center;
                noInternet.FontSize = 40;
            }
        }
    }
}
