﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// Pour plus d'informations sur le modèle d'élément Page vierge, consultez la page https://go.microsoft.com/fwlink/?LinkId=234238

namespace WinPlex
{
    /// <summary>
    /// Une page vide peut être utilisée seule ou constituer une page de destination au sein d'un frame.
    /// </summary>
    public sealed partial class Meteo : Page
    {
        public Meteo()
        {
            this.InitializeComponent();
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                var position = await LocationManager.GetPosition();

                var lat = position.Coordinate.Point.Position.Latitude;
                var lon = position.Coordinate.Point.Position.Longitude;

                MeteoDB maMeteo = await MapMeteo.GetWeather(lat, lon);

                //Schedule update
                var uri = String.Format("http://lk-uwpweatherservice.azurewebsites.net/?lat={0}&lon={1}", lat, lon);

                var tileContent = new Uri(uri);
                var tempsRequete = PeriodicUpdateRecurrence.HalfHour;
                var updater = TileUpdateManager.CreateTileUpdaterForApplication();
                updater.StartPeriodicUpdate(tileContent, tempsRequete);


                string icon = String.Format("http://openweathermap.org/img/w/{0}.png", maMeteo.weather[0].icon);

                TempTextBlock.Text = ((int)maMeteo.main.temp).ToString() + "°C";
                DescTextBlock.Text = maMeteo.weather[0].description;
                LocationTextBlock.Text = maMeteo.name;

                ResultImage.Source = new BitmapImage(new Uri(icon, UriKind.Absolute));
            }
            catch
            {
                LocationTextBlock.Text = "Impossible de connaître la météo. Veuillez-réaisser plutart.";
            }
        }
    }
}
